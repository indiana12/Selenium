package com.Selenium;

import java.util.Random;

import org.openqa.selenium.By; //Path according to the xpath and by class import org.openqa.selenium.By.ByPartialLinkText;
import org.openqa.selenium.WebDriver; //Import selenium web driver
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver; //import chrome Driver
import org.openqa.selenium.support.ui.Select;

public class Selenium1 {
	private static WebDriver driver;
	private static WebElement Totalwb;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		//set the path of chrome driver:
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Plucky\\Desktop\\jars and files\\selenium\\chromedriver\\chromedriver.exe");
		
		//method for chrome driver
		driver=new ChromeDriver();
		
		//navigation to w3schools
		driver.navigate().to("http://www.newtours.demoaut.com");
		
		//first step is to click on my account
		//driver.findElement(By.xpath("//a[@class='account_icon']")).click();
		
		//opening the site and finding the first text element from the site
		driver.findElement(By.xpath("//input[@name='userName']")).click();
		
		//giving the username of the textfield as testuser_1
		driver.findElement(By.xpath("//input[@name='userName']")).sendKeys("readonly");
		
		//finding the textfield for password and entering
		driver.findElement(By.xpath("//input[@name='password']")).click();
		
		//entering the password for the given site
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("readonly");
		
		//clicking the login button after entering the credientials
		driver.findElement(By.xpath("//input[@name='login']")).click();
		
		
		/* Creating a checkbox select code */
		//Setting the random number of the function
		Random rd = new Random();
		//setting the random number to integer
		int a =rd.nextInt(4);
		//creating a method to store checkbox web elements
		WebElement wb = driver.findElement(By.xpath("//select[@name='passCount']"));
		//web element click;
		//selects the value from the checkboxes (method).
		Select s1 = new Select(wb);
		//creating a string which takes a value and converts the given string into an integer.
		String ddvalue = Integer.toString(a);
		//setting the visible task of checkbox values into the given elements.
		s1.selectByVisibleText(ddvalue);
		
		
		 
		WebElement wb1 = driver.findElement(By.xpath("//select[@name='fromPort']"));
		Select s2=new Select(wb1);
		//String ddvalue1= Integer.toString(a1); 
		s2.selectByIndex(4);//(ddvalue1);
		
		
		
		WebElement wb2 = driver.findElement(By.xpath("//select[@name='fromMonth']"));
		Select s3=new Select(wb2);
		//String ddvalue1= Integer.toString(a1); 
		s3.selectByIndex(4);//(ddvalue1);
		
		Random rd1 = new Random();
		int a1 = rd1.nextInt(5);
		WebElement wb3 = driver.findElement(By.xpath("//select[@name='fromDay']"));
		Select s4 = new Select(wb3);
		String ddvalue1 = Integer.toString(a1);
		s4.selectByVisibleText(ddvalue1);
		
		
		
		
		
		System.out.println("opened the browser");
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
		
		
	}

	